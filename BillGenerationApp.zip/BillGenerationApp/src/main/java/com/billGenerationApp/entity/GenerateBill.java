package com.billGenerationApp.entity;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="Bill")
public class GenerateBill {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	int billId;
	
	
	@Column(name="productDescription")
	String productDescription ;
	
	@Column(name="unitPrice")
	int unitPrice ;
	
	@Column(name="qty")
	int qty;
	
	@Column(name="totalCost")
	int totalCost;
	
	@Column(name="productID")
	int productID ;
	
	@Column(name="SalesmanId")
	int SalesmanId;
	
	
}
