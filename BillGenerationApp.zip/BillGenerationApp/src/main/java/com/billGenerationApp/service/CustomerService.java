package com.billGenerationApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billGenerationApp.repository.CustomerRepository;
import com.billGenerationApp.repository.ProductRepository;

@Service
public class CustomerService {
	
	@Autowired
	public CustomerRepository customerRepository;

}
