package com.billGenerationApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billGenerationApp.entity.GenerateBill;
import com.billGenerationApp.repository.GenerateBillRepository;

@Service
public class GenerateBillService {

	
	@Autowired
	public GenerateBillRepository generateBillRepository;
	
	public void save(GenerateBill bill) {
		generateBillRepository.save(bill);	
	}
}
