package com.billGenerationApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billGenerationApp.entity.Product;
import com.billGenerationApp.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	public ProductRepository productRepository;

	public List<Product> getAllProducts(){
		return productRepository.findAll();
	}
	
	public void save(Product product) {
		productRepository.save(product);
	}
	
	public void delete(int id) {
		productRepository.deleteById(id);
	}
}
