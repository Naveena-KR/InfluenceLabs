package com.billGenerationApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billGenerationApp.repository.ProductRepository;
import com.billGenerationApp.repository.SalesManRepository;

@Service
public class SalesManService {
	
	@Autowired
	public SalesManRepository salesManRepository;

}
