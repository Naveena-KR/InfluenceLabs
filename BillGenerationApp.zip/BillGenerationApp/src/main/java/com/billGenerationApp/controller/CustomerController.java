package com.billGenerationApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.billGenerationApp.service.CustomerService;

@RestController
@RequestMapping("/customerController")
public class CustomerController {
	
	@Autowired
	public CustomerService customerService;

}
