package com.billGenerationApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.billGenerationApp.entity.GenerateBill;
import com.billGenerationApp.service.GenerateBillService;

@Controller
@RequestMapping("/generateBill")
public class GenerateBillController {
	
	@Autowired
	public GenerateBillService generateBillService;
	
	@RequestMapping("/creatBill")
	public String createBill(Model model)
	{
		GenerateBill bill = new GenerateBill();
	    model.addAttribute("bill",bill);
		return "bill";
	}
	
	
	@RequestMapping("/printBill")
	public String printBill(Model model,@ModelAttribute("billData")GenerateBill bill)
	{   
		generateBillService.save(bill);
		model.addAttribute("bill",bill);
		return "printBill";
	}

}
