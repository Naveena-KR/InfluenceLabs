package com.billGenerationApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.billGenerationApp.service.SalesManService;

@RestController
@RequestMapping("/salesManController")
public class SalesManController {
	
	@Autowired
	public SalesManService salesManService;

}
