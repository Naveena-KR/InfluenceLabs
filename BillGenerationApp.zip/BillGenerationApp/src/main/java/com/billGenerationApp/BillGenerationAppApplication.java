package com.billGenerationApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillGenerationAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillGenerationAppApplication.class, args);
		System.out.println("Running Bill Generation Application");
	}

}
