package com.billGenerationApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billGenerationApp.entity.GenerateBill;

@Repository
public interface GenerateBillRepository extends JpaRepository<GenerateBill,Integer>{

}
