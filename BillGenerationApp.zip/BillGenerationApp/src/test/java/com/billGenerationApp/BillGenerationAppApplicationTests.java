package com.billGenerationApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillGenerationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
